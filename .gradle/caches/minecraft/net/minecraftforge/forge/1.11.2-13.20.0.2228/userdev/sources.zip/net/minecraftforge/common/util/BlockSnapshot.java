/*
 * Minecraft Forge
 * Copyright (c) 2016.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation version 2.1
 * of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

package net.minecraftforge.common.util;

import java.io.Serializable;

import net.minecraft.block.state.IBlockState;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.fml.common.registry.ForgeRegistries;

import javax.annotation.Nullable;

/**
 * Represents a captured snapshot of a block which will not change
 * automatically.
 * <p>
 * Unlike Block, which only one object can exist per coordinate, BlockSnapshot
 * can exist multiple times for any given Block.
 */
@SuppressWarnings({"serial", "deprecation"})
public class BlockSnapshot implements Serializable
{
    private static final boolean DEBUG = Boolean.parseBoolean(System.getProperty("forge.debugBlockSnapshot", "false"));

    private final BlockPos pos;
    private final int dimId;
    private transient IBlockState replacedBlock;
    private int flag;
    @Nullable
    private final NBTTagCompound nbt;
    private transient World world;
    private final ResourceLocation registryName;
    private final int meta;

    public BlockSnapshot(World world, BlockPos pos, IBlockState state)
    {
        this.setWorld(world);
        this.dimId = world.field_73011_w.getDimension();
        this.pos = pos;
        this.setReplacedBlock(state);
        this.registryName = state.func_177230_c().getRegistryName();
        this.meta = state.func_177230_c().func_176201_c(state);
        this.setFlag(3);
        TileEntity te = world.func_175625_s(pos);
        if (te != null)
        {
            nbt = new NBTTagCompound();
            te.func_189515_b(getNbt());
        }
        else nbt = null;
        if (DEBUG)
        {
            System.out.printf("Created BlockSnapshot - [World: %s ][Location: %d,%d,%d ][Block: %s ][Meta: %d ]", world.func_72912_H().func_76065_j(), pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p(), getRegistryName(), getMeta());
        }
    }

    public BlockSnapshot(World world, BlockPos pos, IBlockState state, @Nullable NBTTagCompound nbt)
    {
        this.setWorld(world);
        this.dimId = world.field_73011_w.getDimension();
        this.pos = pos.func_185334_h();
        this.setReplacedBlock(state);
        this.registryName = state.func_177230_c().getRegistryName();
        this.meta = state.func_177230_c().func_176201_c(state);
        this.setFlag(3);
        this.nbt = nbt;
        if (DEBUG)
        {
            System.out.printf("Created BlockSnapshot - [World: %s ][Location: %d,%d,%d ][Block: %s ][Meta: %d ]", world.func_72912_H().func_76065_j(), pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p(), getRegistryName(), getMeta());
        }
    }

    public BlockSnapshot(World world, BlockPos pos, IBlockState state, int flag)
    {
        this(world, pos, state);
        this.setFlag(flag);
    }

    /**
     * Raw constructor designed for serialization usages.
     */
    public BlockSnapshot(int dimension, BlockPos pos, String modId, String blockName, int meta, int flag, @Nullable NBTTagCompound nbt)
    {
        this.dimId = dimension;
        this.pos = pos.func_185334_h();
        this.setFlag(flag);
        this.registryName = new ResourceLocation(modId, blockName);
        this.meta = meta;
        this.nbt = nbt;
    }

    public static BlockSnapshot getBlockSnapshot(World world, BlockPos pos)
    {
        return new BlockSnapshot(world, pos, world.func_180495_p(pos));
    }

    public static BlockSnapshot getBlockSnapshot(World world, BlockPos pos, int flag)
    {
        return new BlockSnapshot(world, pos, world.func_180495_p(pos), flag);
    }

    public static BlockSnapshot readFromNBT(NBTTagCompound tag)
    {
        NBTTagCompound nbt = tag.func_74767_n("hasTE") ? null : tag.func_74775_l("tileEntity");

        return new BlockSnapshot(
                tag.func_74762_e("dimension"),
                new BlockPos(tag.func_74762_e("posX"), tag.func_74762_e("posY"), tag.func_74762_e("posZ")),
                tag.func_74779_i("blockMod"),
                tag.func_74779_i("blockName"),
                tag.func_74762_e("metadata"),
                tag.func_74762_e("flag"),
                nbt);
    }

    public IBlockState getCurrentBlock()
    {
        return getWorld().func_180495_p(getPos());
    }

    public World getWorld()
    {
        if (this.world == null)
        {
            this.world = DimensionManager.getWorld(getDimId());
        }
        return this.world;
    }

    public IBlockState getReplacedBlock()
    {
        if (this.replacedBlock == null)
        {
            this.replacedBlock = ForgeRegistries.BLOCKS.getValue(this.getRegistryName()).func_176203_a(getMeta());
        }
        return this.replacedBlock;
    }

    public TileEntity getTileEntity()
    {
        if (getNbt() != null)
            return TileEntity.func_190200_a(getWorld(), getNbt());
        else return null;
    }

    public boolean restore()
    {
        return restore(false);
    }

    public boolean restore(boolean force)
    {
        return restore(force, true);
    }

    public boolean restore(boolean force, boolean applyPhysics)
    {
        IBlockState current = getCurrentBlock();
        IBlockState replaced = getReplacedBlock();
        if (current.func_177230_c() != replaced.func_177230_c() || current.func_177230_c().func_176201_c(current) != replaced.func_177230_c().func_176201_c(replaced))
        {
            if (force)
            {
                getWorld().func_180501_a(getPos(), replaced, applyPhysics ? 3 : 2);
            }
            else
            {
                return false;
            }
        }

        getWorld().func_180501_a(getPos(), replaced, applyPhysics ? 3 : 2);
        getWorld().func_184138_a(getPos(), current, replaced, applyPhysics ? 3 : 2);
        TileEntity te = null;
        if (getNbt() != null)
        {
            te = getWorld().func_175625_s(getPos());
            if (te != null)
            {
                te.func_145839_a(getNbt());
                te.func_70296_d();
            }
        }

        if (DEBUG)
        {
            System.out.printf("Restored BlockSnapshot with data [World: %s ][Location: %d,%d,%d ][Meta: %d ][Block: %s ][TileEntity: %s ][force: %s ][applyPhysics: %s]", getWorld().func_72912_H().func_76065_j(), getPos().func_177958_n(), getPos().func_177956_o(), getPos().func_177952_p(), replaced.func_177230_c().func_176201_c(replaced), replaced.func_177230_c().delegate.name(), te, force, applyPhysics);
        }
        return true;
    }

    public boolean restoreToLocation(World world, BlockPos pos, boolean force, boolean applyPhysics)
    {
        IBlockState current = getCurrentBlock();
        IBlockState replaced = getReplacedBlock();
        if (current.func_177230_c() != replaced.func_177230_c() || current.func_177230_c().func_176201_c(current) != replaced.func_177230_c().func_176201_c(replaced))
        {
            if (force)
            {
                world.func_180501_a(pos, replaced, applyPhysics ? 3 : 2);
            }
            else
            {
                return false;
            }
        }

        world.func_180501_a(pos, replaced, applyPhysics ? 3 : 2);
        world.func_184138_a(pos, current, replaced, applyPhysics ? 3 : 2);
        TileEntity te = null;
        if (getNbt() != null)
        {
            te = world.func_175625_s(pos);
            if (te != null)
            {
                te.func_145839_a(getNbt());
                te.func_70296_d();
            }
        }

        if (DEBUG)
        {
            System.out.printf("Restored BlockSnapshot with data [World: %s ][Location: %d,%d,%d ][Meta: %d ][Block: %s ][TileEntity: %s ][force: %s ][applyPhysics: %s]", world.func_72912_H().func_76065_j(), pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p(), replaced.func_177230_c().func_176201_c(replaced), replaced.func_177230_c().delegate.name(), te, force, applyPhysics);
        }
        return true;
    }

    public void writeToNBT(NBTTagCompound compound)
    {
        compound.func_74778_a("blockMod", getRegistryName().func_110624_b());
        compound.func_74778_a("blockName", getRegistryName().func_110623_a());
        compound.func_74768_a("posX", getPos().func_177958_n());
        compound.func_74768_a("posY", getPos().func_177956_o());
        compound.func_74768_a("posZ", getPos().func_177952_p());
        compound.func_74768_a("flag", getFlag());
        compound.func_74768_a("dimension", getDimId());
        compound.func_74768_a("metadata", getMeta());

        compound.func_74757_a("hasTE", getNbt() != null);

        if (getNbt() != null)
        {
            compound.func_74782_a("tileEntity", getNbt());
        }
    }

    @Override
    public boolean equals(Object obj)
    {
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        final BlockSnapshot other = (BlockSnapshot) obj;
        if (!this.getPos().equals(other.getPos()))
        {
            return false;
        }
        if (this.getMeta() != other.getMeta())
        {
            return false;
        }
        if (this.getDimId() != other.getDimId())
        {
            return false;
        }
        if (this.getNbt() != other.getNbt() && (this.getNbt() == null || !this.getNbt().equals(other.getNbt())))
        {
            return false;
        }
        if (this.getWorld() != other.getWorld() && (this.getWorld() == null || !this.getWorld().equals(other.getWorld())))
        {
            return false;
        }
        if (this.getRegistryName() != other.getRegistryName() && (this.getRegistryName() == null || !this.getRegistryName().equals(other.getRegistryName())))
        {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode()
    {
        int hash = 7;
        hash = 73 * hash + this.getPos().func_177958_n();
        hash = 73 * hash + this.getPos().func_177956_o();
        hash = 73 * hash + this.getPos().func_177952_p();
        hash = 73 * hash + this.getMeta();
        hash = 73 * hash + this.getDimId();
        hash = 73 * hash + (this.getNbt() != null ? this.getNbt().hashCode() : 0);
        hash = 73 * hash + (this.getWorld() != null ? this.getWorld().hashCode() : 0);
        hash = 73 * hash + (this.getRegistryName() != null ? this.getRegistryName().hashCode() : 0);
        return hash;
    }

    public BlockPos getPos() { return pos; }
    public int getDimId() { return dimId; }
    public void setReplacedBlock(IBlockState replacedBlock) { this.replacedBlock = replacedBlock; }
    public int getFlag() { return flag; }
    public void setFlag(int flag) { this.flag = flag; }
    @Nullable
    public NBTTagCompound getNbt() { return nbt; }
    public void setWorld(World world) { this.world = world; }
    public ResourceLocation getRegistryName() { return registryName; }
    public int getMeta() { return meta; }
}
