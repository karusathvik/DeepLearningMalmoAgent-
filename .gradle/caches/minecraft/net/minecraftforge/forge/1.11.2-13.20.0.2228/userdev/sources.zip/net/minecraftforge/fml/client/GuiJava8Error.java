/*
 * Minecraft Forge
 * Copyright (c) 2016.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation version 2.1
 * of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

package net.minecraftforge.fml.client;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiErrorScreen;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.FMLLog;
import net.minecraftforge.fml.common.Java8VersionException;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.ModContainer;
import org.apache.logging.log4j.Level;

import com.google.common.collect.Lists;

import java.awt.*;
import java.io.IOException;
import java.net.URI;
import java.util.List;

public class GuiJava8Error extends GuiErrorScreen
{
    private Java8VersionException java8VersionException;
    public GuiJava8Error(Java8VersionException java8VersionException)
    {
        super(null,null);
        this.java8VersionException = java8VersionException;
    }

    @Override
    public void func_73866_w_()
    {
        this.field_146292_n.clear();
        this.field_146292_n.add(new GuiButton(1, 50, this.field_146295_m - 38, this.field_146294_l/2 -55, 20, I18n.func_135052_a("fml.button.visitjavadownloads")));
        if (java8VersionException.getMods().isEmpty())
        {
            this.field_146292_n.add(new GuiButton(3, this.field_146294_l / 2 + 5, this.field_146295_m - 38, this.field_146294_l / 2 - 55, 20, I18n.func_135052_a("fml.button.continue")));
        }
        else
        {
            this.field_146292_n.add(new GuiButton(2, this.field_146294_l / 2 + 5, this.field_146295_m - 38, this.field_146294_l / 2 - 55, 20, I18n.func_135052_a("menu.quit")));
        }
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException
    {
        if (button.field_146127_k == 1)
        {
            try
            {
                Desktop.getDesktop().browse(new URI("http://www.oracle.com/technetwork/java/javase/downloads/index.html"));
            }
            catch (Exception e)
            {
                FMLLog.log(Level.ERROR, e, "Problem launching browser");
            }
        }
        else if (button.field_146127_k == 2)
        {
            FMLCommonHandler.instance().exitJava(1,true);
        }
        else if (button.field_146127_k == 3)
        {
            FMLClientHandler.instance().showGuiScreen(null);
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks)
    {
        this.func_146276_q_();
        int offset = 25;
        if (!java8VersionException.getMods().isEmpty())
        {
            this.func_73732_a(this.field_146289_q, I18n.func_135052_a("fml.messages.java8problem", TextFormatting.RED, TextFormatting.BOLD, TextFormatting.RESET), this.field_146294_l / 2, offset, 0xFFFFFF);
        }
        else
        {
            this.func_73732_a(this.field_146289_q, I18n.func_135052_a("fml.messages.java8recommended", TextFormatting.RED, TextFormatting.BOLD, TextFormatting.RESET), this.field_146294_l / 2, offset, 0xFFFFFF);
        }
        offset+=15;
        this.func_73732_a(this.field_146289_q, I18n.func_135052_a("fml.messages.javaversion", System.getProperty("java.version").split("\\.")[1], System.getProperty("java.version")), this.field_146294_l / 2, offset, 0xFFFFFF);
        offset += 10;
        if (!java8VersionException.getMods().isEmpty())
        {
            this.func_73732_a(this.field_146289_q, I18n.func_135052_a("fml.messages.upgradejavaorremove", TextFormatting.RED,TextFormatting.BOLD, TextFormatting.RESET), this.field_146294_l / 2, offset, 0xFFFFFF);
            offset += 15;
            this.func_73732_a(this.field_146289_q, I18n.func_135052_a("fml.messages.modslistedbelow", I18n.func_135052_a("fml.messages.requirejava8")), this.field_146294_l / 2, offset, 0xFFFFFF);
            offset += 10;
            this.func_73732_a(this.field_146289_q, I18n.func_135052_a("fml.messages.countbadandgood", java8VersionException.getMods().size(), Loader.instance().getActiveModList().size()), this.field_146294_l / 2, offset, 0xFFFFFF);
            offset += 5;
            for (ModContainer mc : java8VersionException.getMods())
            {
                offset += 10;
                this.func_73732_a(this.field_146289_q, String.format("%s (%s)", mc.getName(), mc.getModId()), this.field_146294_l / 2, offset, 0xEEEEEE);
            }
        }
        else
        {
            String text = I18n.func_135052_a("fml.messages.upgradejava", TextFormatting.RED,TextFormatting.BOLD, TextFormatting.RESET).replaceAll("\\\\n", "\n");
            List<String> lines = Lists.newArrayList();
            for (String line : text.split("\n"))
            {
                lines.addAll(this.field_146289_q.func_78271_c(line, this.field_146294_l - this.field_146289_q.field_78288_b * 4));
            }

            int maxWidth = 0;
            for (String line : lines)
            {
                maxWidth = Math.max(maxWidth, this.field_146289_q.func_78256_a(line));
            }

            for (String line : lines)
            {
                this.func_73731_b(this.field_146289_q, line, (this.field_146294_l - maxWidth) / 2, offset, 0xFFFFFF);
                offset += this.field_146289_q.field_78288_b + 2;
            }

            offset += 15;
        }
        // super.super
        for (int i = 0; i < this.field_146292_n.size(); ++i)
        {
            ((GuiButton)this.field_146292_n.get(i)).func_146112_a(this.field_146297_k, mouseX, mouseY);
        }
    }
}
