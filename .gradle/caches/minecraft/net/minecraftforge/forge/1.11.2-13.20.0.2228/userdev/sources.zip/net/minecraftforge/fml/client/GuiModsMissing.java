/*
 * Minecraft Forge
 * Copyright (c) 2016.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation version 2.1
 * of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

package net.minecraftforge.fml.client;

import java.awt.*;
import java.io.File;
import java.io.IOException;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiErrorScreen;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.common.FMLLog;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.MissingModsException;
import net.minecraftforge.fml.common.versioning.ArtifactVersion;
import net.minecraftforge.fml.common.versioning.DefaultArtifactVersion;
import org.apache.logging.log4j.Level;

public class GuiModsMissing extends GuiErrorScreen
{
    private File minecraftDir = new File(Loader.instance().getConfigDir().getParent());
    private File clientLog = new File(minecraftDir, "logs/fml-client-latest.log");
    private MissingModsException modsMissing;

    public GuiModsMissing(MissingModsException modsMissing)
    {
        super(null,null);
        this.modsMissing = modsMissing;
    }

    @Override
    public void func_73866_w_()
    {
        super.func_73866_w_();
        this.field_146292_n.clear();
        this.field_146292_n.add(new GuiButton(1, 50, this.field_146295_m - 38, this.field_146294_l/2 -55, 20, I18n.func_135052_a("fml.button.open.mods.folder")));
        String openFileText = I18n.func_135052_a("fml.button.open.file", clientLog.getName());
        this.field_146292_n.add(new GuiButton(2, this.field_146294_l / 2 + 5, this.field_146295_m - 38, this.field_146294_l / 2 - 55, 20, openFileText));
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException
    {
        if (button.field_146127_k == 1)
        {
            try
            {
                File modsDir = new File(minecraftDir, "mods");
                Desktop.getDesktop().open(modsDir);
            }
            catch (Exception e)
            {
                FMLLog.log(Level.ERROR, e, "Problem opening mods folder");
            }
        }
        else if (button.field_146127_k == 2)
        {
            try
            {
                Desktop.getDesktop().open(clientLog);
            }
            catch (Exception e)
            {
                FMLLog.log(Level.ERROR, e, "Problem opening log file " + clientLog);
            }
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks)
    {
        this.func_146276_q_();
        int offset = Math.max(85 - modsMissing.missingMods.size() * 10, 10);
        String modMissingDependenciesText = I18n.func_135052_a("fml.messages.mod.missing.dependencies", TextFormatting.BOLD + modsMissing.getModName() + TextFormatting.RESET);
        this.func_73732_a(this.field_146289_q, modMissingDependenciesText, this.field_146294_l / 2, offset, 0xFFFFFF);
        offset+=10;
        String fixMissingDependenciesText = I18n.func_135052_a("fml.messages.mod.missing.dependencies.fix", modsMissing.getModName());
        this.func_73732_a(this.field_146289_q, fixMissingDependenciesText, this.field_146294_l / 2, offset, 0xFFFFFF);
        offset+=5;
        for (ArtifactVersion v : modsMissing.missingMods)
        {
            offset+=10;
            if (v instanceof DefaultArtifactVersion)
            {
                DefaultArtifactVersion dav =  (DefaultArtifactVersion)v;
                if (dav.getRange() != null)
                {
                    String message = String.format(TextFormatting.BOLD +  "%s " + TextFormatting.RESET + "%s", v.getLabel(), dav.getRange().toStringFriendly());
                    this.func_73732_a(this.field_146289_q, message, this.field_146294_l / 2, offset, 0xEEEEEE);
                    continue;
                }
            }
            this.func_73732_a(this.field_146289_q, String.format("%s : %s", v.getLabel(), v.getRangeString()), this.field_146294_l / 2, offset, 0xEEEEEE);
        }
        offset+=20;
        String seeLogText = I18n.func_135052_a("fml.messages.mod.missing.dependencies.see.log", clientLog.getName());
        this.func_73732_a(this.field_146289_q, seeLogText, this.field_146294_l / 2, offset, 0xFFFFFF);

        for (int i = 0; i < this.field_146292_n.size(); ++i)
        {
            this.field_146292_n.get(i).func_146112_a(this.field_146297_k, mouseX, mouseY);
        }
    }
}
