/*
 * Minecraft Forge
 * Copyright (c) 2016.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation version 2.1
 * of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

package net.minecraftforge.client.model;

import java.util.List;

import javax.vecmath.Matrix4f;

import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
import net.minecraft.client.renderer.block.model.ItemOverrideList;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.model.IModelState;
import net.minecraftforge.common.model.TRSRTransformation;

import org.apache.commons.lang3.tuple.Pair;

import com.google.common.base.Optional;
import com.google.common.collect.ImmutableMap;

/*
 * Model that changes based on the rendering perspective
 * (first-person, GUI, e.t.c - see TransformType)
 */
public interface IPerspectiveAwareModel extends IBakedModel
{
    /*
     * Returns the pair of the model for the given perspective, and the matrix
     * that should be applied to the GL state before rendering it (matrix may be null).
     */
    Pair<? extends IBakedModel, Matrix4f> handlePerspective(TransformType cameraTransformType);

    public static class MapWrapper implements IPerspectiveAwareModel
    {
        private final IBakedModel parent;
        private final ImmutableMap<TransformType, TRSRTransformation> transforms;

        public MapWrapper(IBakedModel parent, ImmutableMap<TransformType, TRSRTransformation> transforms)
        {
            this.parent = parent;
            this.transforms = transforms;
        }

        public MapWrapper(IBakedModel parent, IModelState state)
        {
            this(parent, getTransforms(state));
        }

        public static ImmutableMap<TransformType, TRSRTransformation> getTransforms(IModelState state)
        {
            ImmutableMap.Builder<TransformType, TRSRTransformation> builder = ImmutableMap.builder();
            for(TransformType type : TransformType.values())
            {
                Optional<TRSRTransformation> tr = state.apply(Optional.of(type));
                if(tr.isPresent())
                {
                    builder.put(type, tr.get());
                }
            }
            return builder.build();
        }

        @SuppressWarnings("deprecation")
        public static ImmutableMap<TransformType, TRSRTransformation> getTransforms(ItemCameraTransforms transforms)
        {
            ImmutableMap.Builder<TransformType, TRSRTransformation> builder = ImmutableMap.builder();
            for(TransformType type : TransformType.values())
            {
                builder.put(type, TRSRTransformation.blockCenterToCorner(new TRSRTransformation(transforms.func_181688_b(type))));
            }
            return builder.build();
        }

        public static Pair<? extends IBakedModel, Matrix4f> handlePerspective(IBakedModel model, ImmutableMap<TransformType, TRSRTransformation> transforms, TransformType cameraTransformType)
        {
            TRSRTransformation tr = transforms.get(cameraTransformType);
            Matrix4f mat = null;
            if(tr != null && !tr.equals(TRSRTransformation.identity())) mat = TRSRTransformation.blockCornerToCenter(tr).getMatrix();
            return Pair.of(model, mat);
        }

        public static Pair<? extends IBakedModel, Matrix4f> handlePerspective(IBakedModel model, IModelState state, TransformType cameraTransformType)
        {
            TRSRTransformation tr = state.apply(Optional.of(cameraTransformType)).or(TRSRTransformation.identity());
            if(tr != TRSRTransformation.identity())
            {
                return Pair.of(model, TRSRTransformation.blockCornerToCenter(tr).getMatrix());
            }
            return Pair.of(model, null);
        }

        public boolean func_177555_b() { return parent.func_177555_b(); }
        public boolean func_177556_c() { return parent.func_177556_c(); }
        public boolean func_188618_c() { return parent.func_188618_c(); }
        public TextureAtlasSprite func_177554_e() { return parent.func_177554_e(); }
        @SuppressWarnings("deprecation")
        public ItemCameraTransforms func_177552_f() { return parent.func_177552_f(); }
        public List<BakedQuad> func_188616_a(IBlockState state, EnumFacing side, long rand) { return parent.func_188616_a(state, side, rand); }
        public ItemOverrideList func_188617_f() { return parent.func_188617_f(); }

        @Override
        public Pair<? extends IBakedModel, Matrix4f> handlePerspective(TransformType cameraTransformType)
        {
            return handlePerspective(this, transforms, cameraTransformType);
        }
    }
}
