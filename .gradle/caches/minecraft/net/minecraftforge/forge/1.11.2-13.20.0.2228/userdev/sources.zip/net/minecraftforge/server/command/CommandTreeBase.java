/*
 * Minecraft Forge
 * Copyright (c) 2016.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation version 2.1
 * of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

package net.minecraftforge.server.command;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Base class for commands that has subcommands.
 * <p>
 * E.g. /team settings set [value]
 * settings is subcommand of team and set is subcommand of settings
 */
public abstract class CommandTreeBase extends CommandBase
{
    private final Map<String, ICommand> commandMap = new HashMap<String, ICommand>();

    public void addSubcommand(ICommand c)
    {
        commandMap.put(c.func_71517_b(), c);
    }

    public Collection<ICommand> getSubCommands()
    {
        return getCommandMap().values();
    }

    public Map<String, ICommand> getCommandMap()
    {
        return Collections.unmodifiableMap(commandMap);
    }

    public List<ICommand> getSortedCommandList()
    {
        List<ICommand> list = new ArrayList<ICommand>(getSubCommands());
        Collections.sort(list);
        return list;
    }

    private static String[] shiftArgs(String[] s)
    {
        if(s == null || s.length == 0)
        {
            return new String[0];
        }

        String[] s1 = new String[s.length - 1];
        System.arraycopy(s, 1, s1, 0, s1.length);
        return s1;
    }

    @Override
    @Nonnull
    public List<String> func_184883_a(@Nonnull MinecraftServer server, @Nonnull ICommandSender sender, @Nonnull String[] args, @Nullable BlockPos pos)
    {
        if(args.length == 1)
        {
            List<String> keys = new ArrayList<String>();

            for(ICommand c : getCommandMap().values())
            {
                if(c.func_184882_a(server, sender))
                {
                    keys.add(c.func_71517_b());
                }
            }

            Collections.sort(keys, null);
            return func_175762_a(args, keys);
        }

        ICommand cmd = getCommandMap().get(args[0]);

        if(cmd != null)
        {
            return cmd.func_184883_a(server, sender, shiftArgs(args), pos);
        }

        return super.func_184883_a(server, sender, args, pos);
    }

    @Override
    public boolean func_82358_a(@Nonnull String[] args, int index)
    {
        if(index > 0 && args.length > 1)
        {
            ICommand cmd = getCommandMap().get(args[0]);
            if(cmd != null)
            {
                return cmd.func_82358_a(shiftArgs(args), index - 1);
            }
        }

        return false;
    }

    @Override
    public void func_184881_a(@Nonnull MinecraftServer server, @Nonnull ICommandSender sender, @Nonnull String[] args) throws CommandException
    {
        if(args.length < 1)
        {
            sender.func_145747_a(new TextComponentString(CommandBase.func_96333_a(commandMap.keySet())));
        }
        else
        {
            ICommand cmd = getCommandMap().get(args[0]);

            if(cmd == null)
            {
                throw new CommandException("commands.tree_base.invalid_cmd", args[0]);
            }
            else if(!cmd.func_184882_a(server, sender))
            {
                throw new CommandException("commands.generic.permission");
            }
            else
            {
                cmd.func_184881_a(server, sender, shiftArgs(args));
            }
        }
    }
}
